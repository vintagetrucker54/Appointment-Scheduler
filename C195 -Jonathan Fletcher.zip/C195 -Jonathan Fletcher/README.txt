                                        Appointment Management System C-195
------------------------------------------------------------------------------------------------------------------------
                                     •  title and purpose of the application  •
------------------------------------------------------------------------------------------------------------------------
Appointment Management System for a software company that has been contracted to develop a GUI-based scheduling desktop
application used by businesses to manage appointments for executives and employees as well as contractors and customers.
The company conducts business in multiple languages and has main offices in:
Phoenix, Arizona;
White Plains, New York;
Montreal, Canada; and
London, England
------------------------------------------------------------------------------------------------------------------------
                                     •  directions for how to run the program •
------------------------------------------------------------------------------------------------------------------------
Save the application to your computer and open in IntelliJ.
Click RUN -> Run 'Main'
Login with sample data, username = 'test' with password = 'test' or username = 'admin' with password = 'admin'
------------------------------------------------------------------------------------------------------------------------
                            •  author, contact information, application version, and date •
------------------------------------------------------------------------------------------------------------------------
Jonathan Fletcher jflet63@wgu.edu
App Ver1.01
IDE: IntelliJ IDEA 2020.3.2 (Community Edition), Java SE 15.0.1, JavaFX-SDK-11.0.2
Build #IC-203.7148.57
Runtime version: 11.0.9.1+11-b1145.77 amd64
VM: OpenJDK 64-bit Server VM by JetBrains s.r.o.
Date: 03/14/2021
------------------------------------------------------------------------------------------------------------------------
                      •  a description of the additional report of your choice you ran in part A3f •
------------------------------------------------------------------------------------------------------------------------
Third report shows the schedule based upon the customer selected. Similar to the consultants report but used for
customers instead.